

<?php $__env->startSection('title'); ?>
    My Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-3">
        <div class="row align-items-center justify-content-between">
            <div class="col-4 nav-item nav-search d-none d-md-block mr-0">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search..." aria-label="search"
                        aria-describedby="search" name="search" id="search">
                    <button type="button" onclick=searchProduct() class="btn btn-primary ml-4">Search</button>
                </div>
            </div>
            <div class="col-2">
                <a class="nav-link count-indicator d-flex align-items-center justify-content-center"
                    id="notificationDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                    <i class="typcn typcn-shopping-cart mx-0"></i>
                    <sup class="badge badge-danger ml-1"><?php echo e(count($carts)); ?></sup>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list px-3 py-3"
                    aria-labelledby="notificationDropdown">

                    <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="dropdown-item preview-item" style="width:10rem;">
                            <div class="preview-thumbnail">
                                <div class="preview-icon bg-success">
                                    <img class="mx-0" src="<?php echo e(asset('images/' . $item->picture)); ?>">
                                </div>
                            </div>
                            <div class="preview-item-content">
                                <h6 class="preview-subject font-weight-normal"><?php echo e($item->name); ?></h6>
                                <div
                                    class="row font-weight-light small-text mb-0 text-muted align-items-center justify-content-around">
                                    <form action="/add-quntity/<?php echo e(Auth::user()->id); ?>/<?php echo e($item->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('post'); ?>

                                        <button type="submit" class="btn btn-icon">
                                            <i class="typcn typcn-plus"></i>
                                        </button>
                                    </form>
                                    <h5 class="mb-0"><?php echo e($item->quantity); ?></h5>
                                    <form action="/subtract-quntity/<?php echo e(Auth::user()->id); ?>/<?php echo e($item->id); ?>"
                                        method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('post'); ?>

                                        <button type="submit" class="btn btn-icon">
                                            <i class="typcn typcn-minus"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a class="dropdown-item preview-item justify-content-center align-items-center"
                            style="width:10rem;">
                            <p>Nothing here</p>
                        </a>
                    <?php endif; ?>

                    <?php if(count($carts) > 0): ?>
                        <div class="dropdown-item preview-item align-items-center justify-content-center"
                            style="width:10rem;">
                            <form action="/checkout" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <button class="btn btn-primary" type="submit">Order Now</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th>Products</th>
                        <th>Total Price</th>
                        <th class="text-center">Invoice</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $customerOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($key + 1); ?></td>
                            <td class="text-left">
                                <?php for($i = 0; $i < count($item); $i++): ?>
                                    <?php echo e($item[$i]->name); ?>

                                    <?php if($i < count($item) - 1): ?>
                                        ,
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </td>
                            <td class="text-left">
                                <h5>Rp. <?php echo e($orderdetails[$key][0]->total_price); ?></h5>
                            </td>
                            <td class="text-center">
                                <a href="/download-invoice/<?php echo e($item[0]->order_id); ?>">
                                    <button type="button" class="btn btn-info btn-icon-text">
                                        Download Invoice
                                        <i class="typcn typcn-printer btn-icon-append"></i>
                                    </button>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">There's no orders yet</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        //make funtion on button with search document by id "search" then go to link 
        const searchProduct = () => {
            let search = document.getElementById('search').value;
            window.location.href = `/search-products=${search}`;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.polluxui.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Learn\Laravel\Sanbercode Laravel\laravel-ecommerce\resources\views/dashboard/polluxui/customer/orders.blade.php ENDPATH**/ ?>