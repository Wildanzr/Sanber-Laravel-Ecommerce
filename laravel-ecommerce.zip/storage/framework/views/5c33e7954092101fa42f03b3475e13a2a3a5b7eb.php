<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- base:css -->
  <link rel="stylesheet" href="<?php echo e(asset('/polluxui/vendors/typicons/typicons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/polluxui/vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('/polluxui/css/vertical-layout-light/style.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(asset('/polluxui/images/favicon.png')); ?>" />
  <?php echo $__env->yieldContent('cdn'); ?>
  <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>
 
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
   <?php echo $__env->make('dashboard.polluxui.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- partial undernavbar-->
  
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
   
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
     <?php echo $__env->make('dashboard.polluxui.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
       
        <!-- disini konten -->
        <?php echo $__env->yieldContent('content'); ?>
        
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
            <div class="card">
                <div class="card-body">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 <a href="https://www.bootstrapdash.com/" class="text-muted" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
                        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center text-muted">Free <a href="https://www.bootstrapdash.com/" class="text-muted" target="_blank">Bootstrap dashboard</a> templates from Bootstrapdash.com</span>
                    </div>
                </div>    
            </div>        
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php echo $__env->yieldContent('script'); ?>
  <script src="<?php echo e(asset('/polluxui/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo e(asset('/polluxui/vendors/chart.js/Chart.min.js')); ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(asset('/polluxui/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('/polluxui/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('/polluxui/js/template.js')); ?>"></script>
  <script src="<?php echo e(asset('/polluxui/js/settings.js')); ?>"></script>
  <script src="<?php echo e(asset('/polluxui/js/todolist.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('/polluxui/js/dashboard.js')); ?>"></script>
  <!-- End custom js for this page-->
  <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>

<?php /**PATH G:\Learn\Laravel\Sanbercode Laravel\laravel-ecommerce\resources\views/dashboard/polluxui/partials/master.blade.php ENDPATH**/ ?>