

<?php $__env->startSection('title'); ?>
    Store Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-3">
        <div class="row align-items-center justify-content-between">
            <div class="col-4 nav-item nav-search d-none d-md-block mr-0">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search..." aria-label="search"
                        aria-describedby="search" name="search" id="search">
                    <button type="button" onclick=searchProduct() class="btn btn-primary ml-4">Search</button>
                </div>
            </div>
            <div class="col-2">
                <a class="nav-link count-indicator d-flex align-items-center justify-content-center"
                    id="notificationDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                    <i class="typcn typcn-shopping-cart mx-0"></i>
                    <sup class="badge badge-danger ml-1"><?php echo e(count($carts)); ?></sup>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list px-3 py-3"
                    aria-labelledby="notificationDropdown">

                    <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="dropdown-item preview-item" style="width:10rem;">
                            <div class="preview-thumbnail">
                                <div class="preview-icon bg-success">
                                    <img class="mx-0" src="<?php echo e(asset('images/' . $item->picture)); ?>">
                                </div>
                            </div>
                            <div class="preview-item-content">
                                <h6 class="preview-subject font-weight-normal"><?php echo e($item->name); ?></h6>
                                <div
                                    class="row font-weight-light small-text mb-0 text-muted align-items-center justify-content-around">
                                    <form action="/add-quntity/<?php echo e(Auth::user()->id); ?>/<?php echo e($item->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('post'); ?>

                                        <button type="submit" class="btn btn-icon">
                                            <i class="typcn typcn-plus"></i>
                                        </button>
                                    </form>
                                    <h5 class="mb-0"><?php echo e($item->quantity); ?></h5>
                                    <form action="/subtract-quntity/<?php echo e(Auth::user()->id); ?>/<?php echo e($item->id); ?>"
                                        method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('post'); ?>

                                        <button type="submit" class="btn btn-icon">
                                            <i class="typcn typcn-minus"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a class="dropdown-item preview-item justify-content-center align-items-center"
                            style="width:10rem;">
                            <p>Nothing here</p>
                        </a>
                    <?php endif; ?>
                    <?php if(count($carts) > 0): ?>
                        <div class="dropdown-item preview-item align-items-center justify-content-center" style="width:10rem;">
                            <a href="/checkout">
                                <button class="btn btn-primary" type="button">Order Now</button>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="row px-3 py-3">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-4">
                    <div class="card my-3" style="width: 18rem;">
                        <img class="card-img-top" src="<?php echo e(asset('images/' . $item->picture)); ?>" alt="Card image cap"
                            style="width: 286px; height: 195px; object-fit: cover;">
                        <div class="card-body">
                            <div class="d-flex row justify-content-between">
                                <p class="card-title"><?php echo e($item->name); ?></p>
                                <p class="card-title text-primary">Rp. <?php echo e($item->price); ?></p>
                            </div>
                            <div class="d-flex row justify-content-between align-items-center mb-2">
                                <p class="card-text">Available: <?php echo e($item->stock); ?></p>
                            </div>
                            <div class="d-flex">
                                <form action="/add-to-cart/<?php echo e(Auth::user()->id); ?>/<?php echo e($item->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <button class="btn btn-primary" type="submit">Add to cart</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h3>Tidak Ada Produk Terkini</h3>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        //make funtion on button with search document by id "search" then go to link 
        const searchProduct = () => {
            let search = document.getElementById('search').value;
            window.location.href = `/search-products=${search}`;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.polluxui.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Learn\Laravel\Sanbercode Laravel\laravel-ecommerce\resources\views/dashboard/polluxui/customer/products.blade.php ENDPATH**/ ?>