

<?php $__env->startSection('title'); ?>
    Store Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 'admin'): ?>
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body justify-content-center">
                <h4 class="card-title">Edit Product Category</h4>
                <p class="card-description">
                    Edit Product Category here
                </p>
                <form action="/category/<?php echo e($category->id); ?>" method="post" class="form-inline d-flex justify-content-between">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                    <label class="sr-only" for="inlineFormInputName2">Category</label>
                    <input type="text" class="col-10 form-control mb-2" name="name" id="inlineFormInputName2"
                        placeholder="<?php echo e($category->name); ?>" value=<?php echo e($category->name); ?>>
                    <button type="submit" class="btn btn-primary mb-2">Edit Category</button>

                    <?php if($errors->has('category')): ?>
                        <div class="col-12 alert alert-danger">
                            <p><?php echo e($errors->first('category')); ?></p>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">List Category</h4>
                <p class="card-description">
                    See available product category in our shop
                </p>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Category Name</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($key + 1); ?></td>
                                    <td class="text-left"><?php echo e($item->name); ?></td>
                                    <td class="d-flex justify-content-center">

                                        <form action="/category/<?php echo e($item->id); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>

                                            <button type="button" class="btn btn-info btn-icon-text mx-2">
                                                Edit
                                                <i class="typcn typcn-edit btn-icon-append"></i>                                                                              
                                              </button>
    
                                              <button type="button" class="btn btn-warning btn-icon-text mx-2">
                                                <i class="typcn typcn-shopping-bag btn-icon-prepend"></i>                                                    
                                                See Products
                                              </button>
    
                                            <button type="submit" class="btn btn-danger btn-icon-text mx-2">
                                                <i class="typcn typcn-trash btn-icon-prepend"></i>                                                    
                                                Delete
                                              </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">There's no category</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="container-scroller">
        <div class="container-fluid page-body-wrapper full-page-wrapper">
            <div class="content-wrapper d-flex align-items-center text-center error-page bg-primary">
                <div class="row flex-grow">
                    <div class="col-lg-7 mx-auto text-white">
                        <div class="row align-items-center d-flex flex-row">
                            <div class="error-page-divider text-lg-left pl-lg-4">
                                <h2>SORRY! You dont have access :)</h2>
                            </div>
                        </div>
                        <div class="row mt-5">
                            <div class="col-12 text-center mt-xl-2">
                                <a class="text-white font-weight-medium" href="<?php echo e(url('product')); ?>">Back to home</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.polluxui.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Learn\Laravel\Sanbercode Laravel\laravel-ecommerce\resources\views/dashboard/polluxui/admin/edit-category.blade.php ENDPATH**/ ?>