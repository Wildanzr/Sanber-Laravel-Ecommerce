

<?php $__env->startSection('content'); ?>
<br>
<h3>Detail Product</h3>
<br>
<div class="card m-4">
    <div class="konten m-4">
        <h3><?php echo e($product->name); ?></h3>
    <img src="<?php echo e(asset('images/'.$product->picture)); ?>" width="200px">
    <div class="opacity-50"><p>Stock : <?php echo e($product->stock); ?></p></div>
    <p><?php echo e($product->description); ?></p>
    <h5>Rp : <?php echo e($product->price); ?></h5>
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <a href="<?php echo e(route('product.edit',$product->id)); ?>" class="btn btn-primary btn-sm">Edit Product</a>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.polluxui.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Learn\Laravel\Sanbercode Laravel\laravel-ecommerce\resources\views/dashboard/product/show.blade.php ENDPATH**/ ?>