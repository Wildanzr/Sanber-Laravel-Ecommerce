

<?php $__env->startSection('title'); ?>
    Order Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card px-3 py-3">
        <div class="row align-items-center justify-content-between">
            <div class="col-4 nav-item nav-search d-none d-md-block mr-0">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search..." aria-label="search"
                        aria-describedby="search">
                    <button type="submit" class="btn btn-primary ml-4">Search</button>
                </div>
            </div>
            <div class="col-2">
                <a class="nav-link count-indicator d-flex align-items-center justify-content-center"
                    id="notificationDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                    <i class="typcn typcn-shopping-cart mx-0"></i>
                    <sup class="badge badge-danger ml-1"><?php echo e(count($carts)); ?></sup>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list px-3 py-3"
                    aria-labelledby="notificationDropdown">

                    <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="dropdown-item preview-item" style="width:10rem;">
                            <div class="preview-thumbnail">
                                <div class="preview-icon bg-success">
                                    <img class="mx-0" src="<?php echo e(asset('images/' . $item->picture)); ?>">
                                </div>
                            </div>
                            <div class="preview-item-content">
                                <h6 class="preview-subject font-weight-normal"><?php echo e($item->name); ?></h6>
                                <div
                                    class="row font-weight-light small-text mb-0 text-muted align-items-center justify-content-around">
                                    <form action="/add-quntity/<?php echo e(Auth::user()->id); ?>/<?php echo e($item->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('post'); ?>

                                        <button type="submit" class="btn btn-icon">
                                            <i class="typcn typcn-plus"></i>
                                        </button>
                                    </form>
                                    <h5 class="mb-0"><?php echo e($item->quantity); ?></h5>
                                    <form action="/subtract-quntity/<?php echo e(Auth::user()->id); ?>/<?php echo e($item->id); ?>"
                                        method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('post'); ?>

                                        <button type="submit" class="btn btn-icon">
                                            <i class="typcn typcn-minus"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a class="dropdown-item preview-item justify-content-center align-items-center"
                            style="width:10rem;">
                            <p>Nothing here</p>
                        </a>
                    <?php endif; ?>

                    <?php if(count($carts) > 0): ?>
                        <div class="dropdown-item preview-item align-items-center justify-content-center"
                            style="width:10rem;">
                            <form action="/checkout" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <button class="btn btn-primary" type="submit">Order Now</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th>Picture</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th class="text-center">Quantity</th>
                        <th class="text-center">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($key + 1); ?></td>
                            <td>
                                <img src="<?php echo e(asset('images/' . $item->picture)); ?>"
                                    style="width: 235px; height: 150px; object-fit: cover; border-radius: 0%;"
                                    alt="<?php echo e($item->name); ?>">
                            </td>
                            <td><?php echo e($item->name); ?></td>
                            <td>Rp.<?php echo e($item->price); ?></td>
                            <td class="text-center"><?php echo e($item->quantity); ?></td>
                            <td class="text-right px-5"><b
                                    class="card-title">Rp.<?php echo e($item->price * $item->quantity); ?></b></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3">There's no cart yet</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="5" class="px-5">Total</th>
                        <th class="px-5 text-right">
                            <h2>Rp. <?php echo e($total); ?></h2>
                        </th>
                    </tr>
                </tfoot>
            </table>
            <form action="/order" method="post" class="mt-2 px-5 py-3">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div class="row">
                    <div class="form-group col-12">
                        <div class="col-sm">
                            <label class="form-label"><h5>Order Address To :</h5> </label>
                        </div>
                        <div class="col-sm">
                            <input type="text" class="form-control" name="order_address" placeholder="Your Home Address" required>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <button class="btn btn-info btn-lg btn-block">
                        Order Now
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.polluxui.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Learn\Laravel\Sanbercode Laravel\laravel-ecommerce\resources\views/dashboard/polluxui/customer/checkout.blade.php ENDPATH**/ ?>